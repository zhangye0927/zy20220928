# -*- coding:utf-8 -*-
"""
@Time : 2022/8/3 10:40
@Author: zhangye
@File : Base_Page.py
"""
from time import sleep

from selenium.webdriver import Keys, ActionChains
from selenium.webdriver.support.wait import WebDriverWait


class BasePage:

    # 构造函数
    def __init__(self, driver):
        self.driver = driver


    def open(self, url):
        self.driver.get(url)

    # 定位元素
    def locate(self, name, value):
        el=self.driver.find_element(name, value)
        self.locator_station(el)
        return el

    # 点击操作
    def click(self, name, value):
        self.locate(name, value).click()

    # 输入
    def input(self, name, value, txt):
        self.locate(name, value).send_keys(txt)

    # 退出
    def quit(self,name=1):

        self.driver.quit()

    # 显式等待
    def web_el_wait(self, name, value):
        return WebDriverWait(self.driver, 10, 0.5).until(
            lambda el: self.locate(name, value), message='元素查找失败')

    # 强制等待
    def wait(self, time_):
        sleep(int(time_))

    # 切换Iframe
    def switch_frame(self, value, name=None):
        if name is None:
            self.driver.switch_to.frame(value)
        else:
            self.driver.switch_to.frame(self.locate(name,value))


    # 切换default窗体
    def switch_default(self,name):

         self.driver.switch_to.default_content()

    # 句柄的切换
    def switch_handle(self, close=False, index=1):
        #获取所有句柄
        handles = self.driver.window_handles
        if close:
            self.driver.close()
        self.driver.switch_to.window(handles[index])

    # 断言文本信息：可以捕获异常进行处理，也可以不捕获，因为报错就相当于断言失败。
    def assert_text(self, name, value, expect):
        try:
            reality = self.locate(name, value).text

            assert expect == reality,'断言失败,实际结果为:{},预期结果为:{}'.format(reality,expect)
            return True
        except Exception as e:
            print('断言失败信息：' + str(e))
            return False

        # 获取指定元素的文本
    def get_text(self, name, value):
        return self.locate(name, value).text

    # 获取title
    def get_title(self):
        return self.driver.title

    #获取页面url
    def get_url(self):
        return  self.driver.current_url

      #鼠标悬停
    def move_to(self,name,value):
        el=self.locate(name,value)
        ActionChains(self.driver).move_to_element(el).perform()
        return el.click()

    #js操作滚动条
    def  roll(self,name,value):
              #移动到元素element对象的顶端与当前窗口的顶部对齐
        return self.driver.execute_script('arguments[0].scrollIntoView()',self.locate(name,value))

    #js向富文本中输入
    def inner(self,txt,name,value):
        return self.driver.execute_script('return arguments[0].contentWindow.document.body.innerHTML="{}"'.format(txt),self.locate(name,value))

    # 显示定位的地方，确定定位问题
    def locator_station(self, element):
        self.driver.execute_script(
            "arguments[0].setAttribute('style', arguments[1]);",
            element,
            "border: 2px solid green;"  # 边框border:2px; red红色
        )

        #js操作click
    def jsclick(self,name,value):
        return self.driver.execute_script('return arguments[0].click()',self.locate(name,value))

        # 点击Enter
    def send_enter(self, name, value):

        return self.locate(name, value).send_keys(Keys.ENTER)


        #刷新
    def refresh(self):

        return self.driver.refresh()

       #前进
    def forward(self):
        return self.driver.forward()

      #后退
    def back(self):
        return self.driver.back()

    # 获取title
    def title(self):
        return  self.driver.title

    # js清空文本框
    def clear_(self,name,value):
        return self.driver.execute_script('return arguments[0].value=""', self.locate(name, value))

    #图片输入

    #  背景图片
    def img_upload_Back(self,name,value,filename):
        el = self.locate(name, value)
        el.send_keys(filename)
        return el