# -*- coding:utf-8 -*-
"""
@Time : 2022/8/3 13:12
@Author: zhangye
@File : conftest.py
"""
from selenium import webdriver
from Options.Chrome_Options import ChromeOptions
import pytest
import random
from Data.readYaml import yaMl
import allure

@pytest.fixture(scope='module')
#初始化浏览器，用例的前后置
def browser():
    #用例执行前
    global driver
    driver=webdriver.Chrome(options=ChromeOptions().options())
    driver.implicitly_wait(10)

    #yield 后面带参数是返回
    yield driver

     #用例执行后
    driver.quit()

"""
客户新建数据
"""
@pytest.fixture(scope='function')
def custAdd():
        custName='testNa'+str(random.randint(1,99999999))
        cusNa='test'+str(random.randint(1,99999999))
        custNick='testNc'+str(random.randint(1,99999999))
        cusMail='testMl'+str(random.randint(1,999999))+'@qq.com'
        dict_cus={'custName':custName}
        write_dict=yaMl('./data/cusName.yaml').wirte_Yaml(dict_cus)
        return  custName,cusNa,custNick,cusMail


"""
错误截图
"""
@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    extra = getattr(report, "extra", [])
    if report.when == "call":
        xfail = hasattr(report, "wasxfail")
        if (report.skipped and xfail) or (report.failed and not xfail):
            with allure.step("添加失败截图"):
                allure.attach(driver.get_screenshot_as_png(),
                              "失败截图",allure.attachment_type.PNG)



def pytest_collection_modifyitems(items):
    """
    测试用例收集完成时，将收集到的item的name和nodeid的中文显示在控制台上
    """
    for item in items:
        item.name = item.name.encode("utf-8").decode("unicode_escape")
        item._nodeid = item.nodeid.encode("utf-8").decode("unicode_escape")

