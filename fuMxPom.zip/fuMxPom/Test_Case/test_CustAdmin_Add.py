# -*- coding:utf-8 -*-
"""
@Time : 2022/8/3 13:36
@Author: zhangye
@File : test_CustAdmin_Add.py
"""
import allure
import pytest
from Logic.Cust.Cust_Admin import custAdmin
from Data.readYaml import yaMl
from Logic.Login import loginPage

data=yaMl('./Data/login.yaml').read_Yaml()
#读取账号数据
data_test=[(data['accountA']['Login'],data['accountA']['assert']['expect'])]

cus_sele_data=yaMl('./Data/cusName.yaml').read_Yaml()

#用例等级
@allure.severity("critical")
#用例模块
@allure.feature('客户')
@allure.story('核心业务场景')
class TestCust():

    @allure.title('登录系统')
    @allure.issue('https://fumamx.com/#/main/workbench')
    @allure.testcase('https://fumamx.com/#/main/workbench')
    # 参数化登录
    @pytest.mark.parametrize('test_input,expected', data_test)
    #标记用例
    @pytest.mark.smoke
    def test_Login(self,browser,test_input,expected):
        """
        前置条件：1.初始化浏览器
               步骤：
                   1.打开浏览器，输入系统地址，输入账号密码
                   2.点击登录按钮
               预期结果：
                   1.输入成功
                   2.登录成功

        :param browser:
        :param test_input:
        :param expected:
        :return:
        """
        with allure.step('输入账号密码登录'):
            login=loginPage(browser).login(test_input['login'],test_input['pwd'])
            assert login == expected

    # @pytest.mark.smoke
    @allure.title('新增客户')
    def test_Cust_Add(self,browser,custAdd):
        """
               登录系统，新建客户
               前置条件：1.登录
               步骤
                   1.打开客户管理页面
                   2.点击新建
                   3.输入客户名称，姓名，昵称，邮箱
                   4.点击保存按钮
               预期结果：
                   1.打开成功
                   2.弹出客户新建页面
                   3.输入成功
                   4.保存成功

               """

        with allure.step('输入客户名称、昵称、姓名、邮箱，点击保存'):
            #尝试执行新增
          try:
             cusAdd=custAdmin(browser).csutAdd(*custAdd)
             assert cusAdd == '新增成功'
             #报错跳过
          except Exception as e:
              pass
          #重新登录,在执行新增操作
          else:
              action = self.test_Login()
              cusAdd = custAdmin(browser).csutAdd(*custAdd)
              assert cusAdd == '新增成功'
    @allure.title('查询客户')
    # @pytest.mark.smoke
    def test_cust_Select(self,browser):
        """

               登录系统，新建客户
               前置条件：1.登录
               步骤
                   1.打开客户管理页面
                   2.点击翻页
                   3.点击搜索
                   4.输入客户名，回车
               预期结果：
                   1.打开成功
                   2.翻页成功
                   3.弹出搜索框
                   4.搜索成功

        """
        with allure.step('输入客户名称查询'):
            sel=custAdmin(browser).cus_Sele(cus_sele_data['custName'])
            # sel=self.cust_Select(**cus_sele_data)
            assert '1' in sel