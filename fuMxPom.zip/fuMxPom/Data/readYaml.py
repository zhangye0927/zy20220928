# -*- coding:utf-8 -*-
"""
@Time : 2022/8/3 10:45
@Author: zhangye
@File : readYaml.py
"""
import yaml


class yaMl:
    #初始化文件
    def __init__(self,filename):
        self.filename=filename
     #yaml文件
    def read_Yaml(self):
        with open(self.filename, 'r', encoding='utf-8') as f:
           return yaml.load(f, yaml.FullLoader)
     #写入yaml文件
    def wirte_Yaml(self,data):
        with open(self.filename,'w',encoding='utf-8')as f:
            return yaml.dump(data,stream=f, allow_unicode=True)





if __name__ == '__main__':
    print(yaMl('../Conf/env.yaml').read_Yaml())
    print(yaMl('../Data/login.yaml').read_Yaml())