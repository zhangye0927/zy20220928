# -*- coding:utf-8 -*-
"""
@Time : 2022/8/3 10:58
@Author: zhangye
@File : SigIn_Object.py
"""
from Data.readYaml import yaMl

"""
登录页面元素
"""

url = yaMl('./Conf/env.yaml').read_Yaml()['url'] + '/#/login'
autocomplete_login=('xpath','//input[@type="text"]')
autocomplete_pwd=('xpath','//input[@type="password"]')
button=('xpath',"//button/span[text()='登录']")
button_select=('xpath','//span[text()="储安琪线上发版0929测试企业"]')
button_login=('xpath','//span[text()="进入企业"]')
ass=('xpath','//span[text()="储安琪线上发版0929测试企业"]')