# -*- coding:utf-8 -*-
"""
@Time : 2022/8/3 11:01
@Author: zhangye
@File : Cust_Object.py
"""
from Data.readYaml import yaMl


"""
客户新增页面元素
"""

cust_url=yaMl('./Conf/env.yaml').read_Yaml()['url']+'/#/main/client/tabs/list/BF001'
cust_new=('xpath',"//div[text()='新建']")

cust_cusName=('xpath',"//form[@nameid='custName']/div/div/div/input")

cust_Name=('xpath',"//form[@nameid='contName']/div/div/div/input")

cust_nickName=('xpath',"//form[@nameid='nickName']/div/div/div/input")

cust_cusMail=('xpath',"//form[@nameid='mailAddress']/div/div/div/input")

cust_cusHold=('xpath',"//div[@class='dialogFooter']/button[1]/span")

cust_cusAss=('xpath',"//div[@class='el-message__group']/p")


"""
客户页面查询元素
"""

bill_Sele_butRight=('xpath',"//i[contains(@class,'el-icon-arrow-right')]")
bill_Sele_butLeft=('xpath',"//i[contains(@class,'el-icon-arrow-left')]")
bill_Sele_search=('xpath',"//div[contains(@class,'filter-bar__right')]/div/i")
bill_Sele_input=('xpath',"//div[contains(@class,'filter-bar__right')]/div/input")
