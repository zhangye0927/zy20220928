# -*- coding:utf-8 -*-
"""
@Time : 2022/8/5 13:02
@Author: zhangye
@File : Currency.py
"""

"""
单据通用查询页面
"""

bill_Sele_butRight=('xpath',"//i[contains(@class,'el-icon-arrow-right')]")
bill_Sele_butLeft=('xpath',"//i[contains(@class,'el-icon-arrow-left')]")
bill_Sele_search=('xpath',"//div[contains(@class,'filter-bar__right')]/div/i")
bill_Sele_input=('xpath',"//div[contains(@class,'filter-bar__right')]/div/input")
bill_Sele_Paging=('xpath',"//span[@class='el-pagination__total']")
