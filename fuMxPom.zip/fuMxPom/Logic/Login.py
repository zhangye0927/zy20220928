# -*- coding:utf-8 -*-
"""
@Time : 2022/8/3 11:29
@Author: zhangye
@File : Login.py
"""
from Base.Base_Page import BasePage
import allure
from Page_Object.SigIn_Object import *
class loginPage(BasePage):
    @allure.step('登录')
    def login(self, user, pwd):
        """
        * 解包元祖 ,**解包字典
        :param user: 账户
        :param pwd: 密码
        :return: 断言文本
        """
        self.open(url)
        self.input(*autocomplete_login, txt=user)
        self.input(*autocomplete_pwd, txt=pwd)
        self.click(*button)
        self.click(*button_select)
        self.click(*button_login)
        self.wait(3)
        # self.click('xpath',"//i[@class='avatar__arrow iconfont icon-page-down' ]")
        # self.click('xpath',"//span[contains(text(),'安全退出')]")
        # self.wait(3)

        return self.get_text(*ass)