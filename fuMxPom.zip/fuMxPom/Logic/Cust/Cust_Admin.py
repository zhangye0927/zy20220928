# -*- coding:utf-8 -*-
"""
@Time : 2022/8/3 11:21
@Author: zhangye
@File : Cust_Admin.py
"""

from Logic.bill_Currency import bill_Curr
from Page_Object.Currency import bill_Sele_Paging
from Page_Object.Cust_Object import *
import allure
class custAdmin(bill_Curr):
    @allure.step('新建客户')
    def csutAdd(self,*args):
         """
         :param args: 客户新增参数
         :return:
         """
         self.open(cust_url)
         self.click(*cust_new)
         self.input(*cust_cusName,args[0])
         self.input(*cust_Name,args[1])
         self.input(*cust_nickName,args[2])
         # self.jsclick(*Menu_cust_cusRating)
         self.input(*cust_cusMail,args[3])
         self.wait(1)
         self.click(*cust_cusHold)
         self.wait(5)

         return  self.get_text(*cust_cusAss)

    @allure.step('客户查询')
    def cus_Sele(self,kwargs):

        """
        :param kwargs: 客户编号
        :return:
        """
        cus=self.bill_Sele(cust_url, kwargs)

        return self.get_text(*bill_Sele_Paging)