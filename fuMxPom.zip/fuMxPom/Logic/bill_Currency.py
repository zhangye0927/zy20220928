# -*- coding:utf-8 -*-
"""
@Time : 2022/8/5 11:31
@Author: zhangye
@File : bill_Currency.py
"""
from Base.Base_Page import BasePage
from Page_Object.Currency import *

class bill_Curr(BasePage):
    def bill_Sele(self,url,kwargs):
        self.open(url)
        self.click(*bill_Sele_butRight)
        self.wait(1)
        self.click(*bill_Sele_butLeft)
        self.click(*bill_Sele_search)
        self.clear_(*bill_Sele_input)
        self.input(*bill_Sele_input,kwargs)
        self.wait(1)
        self.send_enter(*bill_Sele_input)
        self.wait(5)
