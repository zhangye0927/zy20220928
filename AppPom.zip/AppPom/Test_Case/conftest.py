# -*- coding:utf-8 -*-
"""
@Time : 2022/8/3 13:12
@Author: zhangye
@File : conftest.py
"""

from appium import webdriver
import pytest
import random
from Data_drive.readYaml import yaMl
import allure
from Logic.Login import login

@pytest.fixture(scope='module')
def logIn():
    #用例执行前
    app_data = yaMl('./Data/APP_info.yaml').read_Yaml()
    global driver
    driver = webdriver.Remote('http://' + str(app_data['ip']) + ':' + str(app_data['port']) + '/wd/hub', app_data)
    driver.implicitly_wait(10)
    user_data=yaMl('./Data/user.yaml').read_Yaml()
    log=login(driver).login(user_data['user'],user_data['pwd'])
    print('app_info:')
    print(app_data)
    print('账号密码:')
    print(user_data)

    yield  driver

    driver.quit()

"""
客户新建数据
"""
@pytest.fixture(scope='function')
def custdata():
        custName='testNa'+str(random.randint(1,99999999))
        print('客户名称:')
        print(custName)
        return  custName

"""
错误截图
"""
@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    extra = getattr(report, "extra", [])
    if report.when == "call":
        xfail = hasattr(report, "wasxfail")
        if (report.skipped and xfail) or (report.failed and not xfail):
            with allure.step("添加失败截图"):
                allure.attach(driver.get_screenshot_as_png(),
                              "失败截图",allure.attachment_type.PNG)



def pytest_collection_modifyitems(items):
    """
    测试用例收集完成时，将收集到的item的name和nodeid的中文显示在控制台上
    """
    for item in items:
        item.name = item.name.encode("utf-8").decode("unicode_escape")
        item._nodeid = item.nodeid.encode("utf-8").decode("unicode_escape")

