# # -*- coding:utf-8 -*-
# """
# @Time : 2022/9/9 14:37
# @Author: zhangye
# @File : test.py
# """
# import uiautomator2 as u2
# from appium import webdriver
# import random
#
# from selenium.webdriver.common.by import By
#
# from Data_drive.readYaml import yaMl
# from Base.Base_Page import *
# data=yaMl('../Data/APP_info.yaml').read_Yaml()
# print(data['ip'])
# print(type(data['ip']))
# print(type(data['port']))
# print(type(data))
# print(data)
# driver=webdriver.Remote('http://' + str(data['ip']) + ':' + str(data['port']) + '/wd/hub', data)
# driver.implicitly_wait(15)
# agree_button_ini=('xpath','//*[@text="同意"]')
# aut_button_ini=('xpath','//*[@text="仅使用期间允许"]')
# autocomplete_login=('id','com.fumamxapp:id/phone')
# autocomplete_pwd=('id','com.fumamxapp:id/pwd')
# button=('id','com.fumamxapp:id/longin')
# agree_button=((289,2313),1000)
# button_select=('xpath','//*[@text="储安琪线上发版0929测试企业"]')
#
# cust=('id','com.fumamxapp:id/kh')
# cust_add_button=('xpath','//*[@text="新增"]')
# cust_add=('xpath','//*[@text="新增客户"]')
#
# cust_name=('xpath','//*[@resource-id="app"]/android.view.View[2]/android.view.View[1]/android.view.View[1]/android.view.View[3]/android.view.View[1]/android.view.View[1]/android.widget.EditText[1]')
#
# cust_save=('xpath','//*[@text="新增"]')
# custdata='testNa'+str(random.randint(1,99999999))
# BasePage(driver).click(*agree_button_ini)
# BasePage(driver).click(*aut_button_ini)
# BasePage(driver).input(*autocomplete_login,'zhangye')
# BasePage(driver).input(*autocomplete_pwd,'513600zx')
# BasePage(driver).wait(2)
# # a=driver.tap([(289,2313)],1000)
# BasePage(driver).top(*agree_button)
# # BasePage(driver).top(*agree_button)
# BasePage(driver).click(*button)
# # BasePage(driver).wait(1)
# BasePage(driver).click(*button_select)
# BasePage(driver).wait(3)
# BasePage(driver).click(*cust)
# con=driver.contexts
# print(con)
# BasePage(driver).click(*cust_add_button)
# BasePage(driver).click(*cust_add)
# BasePage(driver).wait(3)
# con=driver.contexts
# print(con)
#
#
# BasePage(driver).input(*cust_name,txt=custdata)
# BasePage(driver).wait(2)
# BasePage(driver).click(*cust_save)
# BasePage(driver).wait(3)
# driver.quit()
