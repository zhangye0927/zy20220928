# -*- coding:utf-8 -*-
"""
@Time : 2022/9/13 16:36
@Author: zhangye
@File : test_cust.py
"""
import allure
import pytest
from appium import webdriver
from Data_drive.readYaml import yaMl
from Logic.Login import login
from Logic.cust_add import Cust
@allure.epic("孚盟外贸平台-app-ui测试")
class Test_cust():

    @pytest.mark.smoke
    @allure.feature("01.客户管理")
    @allure.story("01.客户管理核心场景")
    @allure.title("01.新增客户")
    def test01(self,logIn, custdata):
        cus=Cust(logIn).custadd(custdata)




