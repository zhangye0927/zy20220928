# -*- coding:utf-8 -*-
"""
@Time : 2022/9/5 13:27
@Author: zhangye
@File : Base_Page.py
"""
from time import sleep

from appium.webdriver.common.multi_action import MultiAction
from appium.webdriver.common.touch_action import TouchAction
from selenium.webdriver.support.wait import WebDriverWait
class  BasePage:

    # 构造函数
    def __init__(self, driver):
        self.driver = driver

    # 定位元素
    def locate1(self, name, value):
        el = self.driver.find_element(name, value)
        self.locator_station(el)
        return el


    # 点击操作
    def click(self, name, value):
        self.locate(name, value).click()

    # 输入
    def input(self, name, value, txt):
        self.locate(name, value).send_keys(txt)

    # 退出
    def quit(self):

        self.driver.quit()

    # 显式等待
    def locate(self, name, value,timeout=10, poll=0.5):
        return WebDriverWait(self.driver, timeout, poll) \
            .until(lambda x: x.find_element(name,value),message='元素查找失败')



    # 强制等待
    def wait(self, time_):
        sleep(int(time_))

    # 切换Iframe
    def switch_frame(self, value, name=None):
        if name is None:
            self.driver.switch_to.frame(value)
        else:
            self.driver.switch_to.frame(self.locate(name, value))

    # 切换default窗体
    def switch_default(self):

        self.driver.switch_to.default_content()

    # 句柄的切换
    def switch_handle(self, close=False, index=1):
        # 获取所有句柄
        handles = self.driver.window_handles
        if close:
            self.driver.close()
        self.driver.switch_to.window(handles[index])

        # 获取指定元素的文本
    def get_text(self, name, value):
        return self.locate(name, value).text


    # js向富文本中输入
    def inner(self, txt, name, value):
        return self.driver.execute_script('return arguments[0].contentWindow.document.body.innerHTML="{}"'.format(txt),self.locate(name, value))

    # 显示定位的地方，确定定位问题
    def locator_station(self, element):
        self.driver.execute_script(
            "arguments[0].setAttribute('style', arguments[1]);",
            element,
            "border: 2px solid green;"  # 边框border:2px; red红色
        )


        # 刷新
    def refresh(self):
        return self.driver.refresh()

    # 前进
    def forward(self):
        return self.driver.forward()

    # 后退
    def back(self):
        return self.driver.back()

    # js清空文本框
    def clear_(self, name, value):
        return self.driver.execute_script('return arguments[0].value=""', self.locate(name, value))


    # 图片输入
    def img_upload_Back(self, name, value, filename):
        el = self.locate(name, value)
        el.send_keys(filename)
        return el

    # 屏幕大小
    def get_size(self):
        #屏幕宽
        x = self.driver.get_window_size()['width']
        #屏幕高
        y = self.driver.get_window_size()['height']
        return x, y

    #滑动-左 坐标的形式
    def swipeLeft(self,n,t):
        """
        :param n: 滑动的次数
        :param t:  滑动的时间
        :return:
        """
        size=self.get_size()

        x1=size[0]*0.8
        y1=size[1]*0.9
        x2=size[0]*0.2
        for i in range(n):
            self.driver.swipe(x1,y1,x2,y1,t)


    # 滑动-右
    def swipeRight(self, n, t):
        size = self.get_size()
        x1 = size[0] * 0.2
        y1 = size[1] * 0.9
        x2 = size[0] * 0.8
        for i in range(n):
            self.driver.swipe(x1, y1, x2, y1, t)

   #元素滑动
    def scroll(self,*args):
        start=self.locate(*args[0])
        end=self.locate(*args[1])
        self.driver.scroll(start,end)

    #切换上下文   h5
    def context(self,index):
        #获取所有的context
        context=self.driver.contexts
        return self.driver.switch_to.context(context[index])


     #键盘  回车键:66
    def keyevent(self,keyword):
        return self.driver.keyevent(keyword)

    # 打开界面
    def startactivity(self,package,activity):
       return self.driver.start_activity(package,activity)

    #轻敲 坐标点击
    def top(self,*args):
        # if switch==0:
        #     el=self.locate(*args[0])
        #     TouchAction(self.driver).tap(el,time_).perform()
        # else:
        self.driver.tap([args[0]],args[1])


    #按下抬起的操作  press(坐标或者元素)按压  release()抬起
    def press(self,*args,switch=None):
        if switch==0:
            el=self.locate(*args[0])
            TouchAction(self.driver).press(el).perform()
        else:
            TouchAction(self.driver).press(*args[0]).perform()
    #按下抬起(长按)
    def long_press(self,*args,switch=None):
        if switch==0:
            el=self.locate(*args[0])
            TouchAction(self.driver).long_press(el).perform()
        else:
            TouchAction(self.driver).long_press(*args[1]).perform()

    # 获取activity
    def current_activity(self):
        return self.driver.current_activity

    #获取当前页面的源
    def page_source(self):
        return self.driver.page_source

    #获取当前url
    def current_url(self):
        return self.driver.current_url

    #两指缩放
    def zoom(self,*args):
        action1=TouchAction(self.driver).press(*args[0]).wait(1000).move_to(*args[1]).wait(1000).release()
        action2=TouchAction(self.driver).press(*args[2]).wait(1000).move_to(*args[3]).wait(1000).release()
        zoom=MultiAction(self.driver)
        zoom.add(action1,action2)
        zoom.perform()


