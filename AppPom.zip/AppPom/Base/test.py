# -*- coding:utf-8 -*-
"""
@Time : 2022/9/5 13:55
@Author: zhangye
@File : test.py
"""


def  aaa():
    x=1080
    x1=x*0.8
    y=980
    return x,y

# b=aaa()
# print(b[0])
# print(type(b))








#
# a=((123,456),789)
# print(type(a))
# print(*a[0],a[1])
# def  aaa1(*args):
#     x=args[0]
#
#     y=args[1]
#     return x,y
#
#
# c=aaa1(*a)
# print(c)

test=('zhng')
print(test)