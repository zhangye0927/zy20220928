# -*- coding:utf-8 -*-
"""
@Time : 2022/9/13 16:28
@Author: zhangye
@File : cust_add.py
"""
from Base.Base_Page import BasePage

from Page_Object.cust_Object import *
print(*cust)

class Cust(BasePage):
    def custadd(self , kwarg):
        self.wait(1)
        self.click(*cust)
        self.click(*cust_add_button)
        self.wait(1)
        self.click(*cust_add)
        self.wait(1)
        self.input(*cust_name , txt=kwarg)
        self.click(*cust_save)
        self.wait(2)