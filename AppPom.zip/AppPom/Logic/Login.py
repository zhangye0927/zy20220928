# -*- coding:utf-8 -*-
"""
@Time : 2022/9/13 14:40
@Author: zhangye
@File : Login.py
"""
from Base.Base_Page import BasePage
from Page_Object.Login_Object import *
class  login(BasePage):
    def login(self,user,pwd):
        self.click(*agree_button_ini)
        self.click(*aut_button_ini)
        self.input(*autocomplete_login,txt=user)
        self.input(*autocomplete_pwd,txt=pwd)
        self.top(*agree_button)
        self.click(*button)
        self.wait(2)
        self.click(*button_select)
        self.wait(6)