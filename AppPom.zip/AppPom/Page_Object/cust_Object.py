# -*- coding:utf-8 -*-
"""
@Time : 2022/9/13 15:33
@Author: zhangye
@File : cust_Object.py
"""
"""
新增客户
"""
entry=('com.fumamxapp','com.fm.mxemail.views.main.activity.MainActivity')
cust=('id','com.fumamxapp:id/kh')
cust_add_button=('xpath','//*[@text="新增"]')
cust_add=('xpath','//*[@text="新增客户"]')
cust_name=('xpath','//*[@resource-id="app"]/android.view.View[2]/android.view.View[1]/android.view.View[1]/android.view.View[3]/android.view.View[1]/android.view.View[1]/android.widget.EditText[1]')

cust_save=('xpath','//*[@text="新增"]')