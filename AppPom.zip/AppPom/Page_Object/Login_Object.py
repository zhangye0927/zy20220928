# -*- coding:utf-8 -*-
"""
@Time : 2022/9/13 13:34
@Author: zhangye
@File : Login_Object.py
"""
"""
登录元素
"""

agree_button_ini=('xpath','//*[@text="同意"]')
aut_button_ini=('xpath','//*[@text="仅使用期间允许"]')
autocomplete_login=('id','com.fumamxapp:id/phone')
autocomplete_pwd=('id','com.fumamxapp:id/pwd')
button=('id','com.fumamxapp:id/longin')
agree_button=((289,2313),1000)
button_select=('xpath','//*[@text="储安琪线上发版0929测试企业"]')

# ass=('xpath','//span[text()="储安琪线上发版0929测试企业"]')