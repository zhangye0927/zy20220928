# -*- coding: utf-8 -*-
'''
    程序主入口:
        1. 调用excel读取执行测试用例
        2. 读取指定路径下所有的excel测试用例
        3. 初始化日志器与关键类
'''
import os

from excel.Conf.log_conf import *
from excel.excel_driver import excel_read

if __name__ == '__main__':
    # 创建日志生成器
    log = get_log(r'D:\pythonProject\excel\excel\Conf\log.ini')

    # 定义测试用例List
    cases = []
    # 获取指定路径下的所有测试用例：用例集中在 data/ 的路径下
    for path, dir, files in os.walk(r'E:\Python\excel\excel\data'):
        print(dir, path)
        # 保存获取的所有测试用例文件：其实就是后缀名为xlsx的文件
        for file in files:
            # 获取文件信息
            file_name = os.path.splitext(file)[0]
            file_type = os.path.splitext(file)[1]
            print(file_type)
            #判断文件是否为excel
            if file_type == '.xlsx':
                # 判断是否需要添加该用例
                if 'old' not in file_name:
                    cases.append(path + '\\' + file)
            else:
                log.info('文件类型错误：{}'.format(file))

    # 调用excel_driver中的run函数，运行测试用例
    for case in cases:
        log.info('正在运行{}测试用例'.format(case))
        excel_read.run(case, log)