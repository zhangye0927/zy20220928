# -*- coding: utf-8 -*-
"""
@Time ： 2021/11/3 20:41
@Auth ： zhangye
@File ：keys.py
@IDE ：PyCharm
"""
from selenium.webdriver import ActionChains

'''
    工具类：结构中层级属于底层逻辑代码层级
    Selenium关键字驱动类：常用操作行为给封装为各类关键字。
        所有的函数，如果不添加return，最后会返回None
        将常用的自行封装到自定义类中，在使用时，直接调用自定义封装的类即可。
        1. 创建driver
        2. 访问url
        3. 定位元素
        4. click
        5. sendkeys
        6. webdriverWait
        7. quit
        8. 相对定位器（由你们课后实现）
        ......
'''

# 自定义关键字驱动类
from time import sleep
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.relative_locator import locate_with
from selenium.webdriver.support.wait import WebDriverWait
from excel.Conf import log_conf
from excel.Conf.chrome_options import ChromeOptions

from selenium.webdriver.common.action_chains import ActionChains

# 基于type_值决定生成的driver对象是什么类型
# def open_browser(type_,log):


def open_browser(type_, log):
    if type_ == 'Chrome':
        driver = webdriver.Chrome(options=ChromeOptions().options())
    else:
        try:
            driver = getattr(webdriver, type_)()
        except Exception as e:
            log.exception('浏览器对象类型输入有误:{}'.format(e))
            driver = webdriver.Chrome()
    return driver


'''
    Python反射机制：
        四大内置函数：常用的是其中的getattr函数，就是获取指定类的指定属性
        getattr(类,属性)   相当于 类.属性 的意思
        例如：
            webdriver.Chrome == getattr(webdriver,'Chrome')
        基于反射获取属性是这个反射函数的基本定义。获取函数就需要在末尾加上()
        例如：
            webdriver.Chrome() == getattr(webdriver,'Chrome')()
    例如open_browser()函数：
        不用反射的形态
            if type_ == Chrome:
                driver = webdriver.Chrome()
            elif type_ == Firefox:
                driver = webdriver.Firefox()
            elif type_ == Ie:
                driver = webdriver.Ie()   
            elif safari
            elif edge

'''


class Keys:
    # 创建临时driver
    # driver = webdriver.Chrome()

    # 构造函数
    # def __init__(self,type_,log):
    def __init__(self, type_, log):
        self.driver = open_browser(type_, log)
        #self.driver = open_browser(type_, log)
        #隐式等待
        self.driver.implicitly_wait(10)
        self.log = log

    # 访问url
    def open(self, url):
        self.driver.get(url)

    # 显示定位的地方，确定定位问题
    def locator_station(self, element):
        self.driver.execute_script(
            "arguments[0].setAttribute('style', arguments[1]);",
            element,
            "border: 2px solid green;"  # 边框border:2px; red红色
        )

    # 定位元素
    def locate(self, name, value):
        el = self.driver.find_element(name, value)
        self.locator_station(el)
        return el

    # 点击操作
    def click(self, name, value):
        self.locate(name, value).click()

    # 输入
    def input(self, name, value, txt):
        self.locate(name, value).send_keys(txt)

    # 退出
    def quit(self, name=1):
        self.driver.quit()

    # 显式等待
    def web_el_wait(self, name, value):
        return WebDriverWait(self.driver, 10, 0.5).until(
            lambda el: self.locate(name, value), message='元素查找失败')

    # 强制等待
    def wait(self, time_):
        sleep(int(time_))

    # 切换Iframe
    def switch_frame(self, value, name=None):
        if name is None:
            self.driver.switch_to.frame(value)
        else:
            self.driver.switch_to.frame(self.locate(value, name))

    # 切换default窗体
    def switch_default(self, name):
        self.driver.switch_to.default_content()

    # 鼠标悬停
    def move_to(self, name, value):
        el = self.locate(name, value)
        ActionChains(self.driver).move_to_element(el).perform()
        return el.click()

        # js操作滚动条
    def roll(self, name, value):
        # 移动到元素element对象的“顶端”与当前窗口的“顶部”对齐
        return self.driver.execute_script('arguments[0].scrollIntoView()', self.locate(name, value))

    # js写入text文本
    def inner(self, txt, name, value):
        return self.driver.execute_script('return arguments[0].contentWindow.document.body.innerHTML="{}"'.format(txt), self.locate(name, value))

    # js操作click
    def jsclick(self, name, value):
        return self.driver.execute_script('return arguments[0].click()', self.locate(name, value))

    # 相对定位器
    def locator_with(self, method, value, el_name, el_value, direction):
        el = self.locate(el_name, el_value)
        direction_dict = {
            'left': 'to_left_of',  # 左侧
            'right': 'to_right_of',  # 右侧
            'above': 'above',  # 上方
            'below': 'below',  # 下方
            'near': 'near'  # 靠近
        }
        if isinstance(method, str):
            method_dict = {
                "id": By.ID,
                "xpath": By.XPATH,
                "link text": By.LINK_TEXT,
                "partial link text": By.PARTIAL_LINK_TEXT,
                "name": By.NAME,
                "tag name": By.TAG_NAME,
                "class name": By.CLASS_NAME,
                "css selector": By.CSS_SELECTOR
            }
            self.locate(locate_with(By.TAG_NAME, 'input').to_left_of(el))
            return self.driver.find_element(getattr(
                locate_with(method_dict.get(method), value), direction_dict.get(direction))(el))

    # 句柄的切换（考虑不同场景的不同切换）
    def switch_handle(self, close=False, index=1):
        handles = self.driver.window_handles
        if close:
            self.driver.close()
        self.driver.switch_to.window(handles[index])

    # 断言文本信息：可以捕获异常进行处理，也可以不捕获，因为报错就相当于断言失败。
    def assert_text(self, name, value, expect):
        try:
            reality = self.locate(name, value).text

            assert expect == reality, '断言失败,实际结果为:{},预期结果为:{}'.format(reality, expect)
            # self.log.info('断言成功，实际结果为：{}'.format(reality))
            return True
        except Exception as e:

            self.log.exception('出现异常，断言失败：{}'.format(e))
            return False

        # 获取指定元素的文本

    def get_text(self, name, value):
        return self.locate(name, value).text