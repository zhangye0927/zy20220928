# -*- coding: utf-8 -*-
"""
@Time ： 2021/11/3 20:39
@Auth ： zhangye
@File ：excel_conf.py
@IDE ：PyCharm
"""
from openpyxl.styles import PatternFill, Font


def write_result(cell, row, column, status=1):
    '''
        status:
            1为Pass
            其他为Failed
    '''
    if status == 1:
        # 写入内容
        cell(row=row, column=column).value = 'Pass'
        # 单元格样式定义：绿色+加粗
        cell(row=row, column=column).fill = PatternFill('solid', fgColor='AACF91')
        cell(row=row, column=column).font = Font(bold=True)
    else:
        # 写入内容
        cell(row=row, column=column).value = 'Failed'
        # 单元格样式定义：红色+加粗
        cell(row=row, column=column).fill = PatternFill('solid', fgColor='FF0000')
        cell(row=row, column=column).font = Font(bold=True)
