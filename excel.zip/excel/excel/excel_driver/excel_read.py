# -*- coding: utf-8 -*-
"""
@Time ： 2021/11/3 20:39
@Auth ： zhangye
@File ：excel_read.py
@IDE ：PyCharm
"""
'''
基于Excel文件的内容去进行读取，并结合获取的数据进行自动化的测试执行
'''
import openpyxl

# 读取excel中的用例正文
from excel.Conf import log_conf
from excel.excel_driver import excel_conf
from excel.web_keys.keys import Keys


def split_(value):
    data = {}
    str_temp = value.split(';')
    # 单元格内容变成字典格式就达到目的：key和value
    for temp in str_temp:
        temp = temp.split('=', 1)
        # 在data字典中增加一组键值对。k-v
        # data.update({temp[0]: temp[1]})
        data[temp[0]] = temp[1]
    return data


def run(file, log):

    excel = openpyxl.load_workbook(file)
    try:
        for name in excel.sheetnames:
            sheet = excel[name]
            log.info('***********{}**************'.format(name))
            for values in sheet.values:
                # 如果第一个单元格是int类型，则表示进入了测试用例的正文

                if type(values[0]) is int:
                 try:
                    if (values[2]) is not None:
                      log.info('当前正在执行：{}'.format(values[3]))
                      data = split_(values[2])
                      print('****************************',data)
                         #实例化关键字驱动
                    if values[1] == 'open_browser':

                        keys = Keys(**data, log=log)
                        # Keys(txt='Chrome')
                       # 断言
                    elif 'assert' in values[1]:
                        status = getattr(keys, values[1])(**data)
                        print(222222222, data)
                        # 基于断言结果True or False来进行写入的操作
                        if status:
                            excel_conf.write_result(sheet.cell, row=values[0] + 2, column=6)
                        else:

                            excel_conf.write_result(sheet.cell, row=values[0] + 2, column=6, status=2)
                     # 断言后的excel写入
                        excel.save(file)

                    else:
                        getattr(keys, values[1])(**data)
                 except:
                    log.exception('定位元素异常：{}'.format(values[3]))

    except Exception as e:
     log.exception('运行异常：{}'.format(e))
    finally:
        excel.close()
    #                 # 基于操作行为和对应参数来执行自动化操作
    #                 '''
    #                     用例的操作行为主要分为：
    #                         1. 实例化，通过一个操作行为实例化关键字驱动类对象
    #                         2. 常规操作，通过调用已实例化的对象，执行对应的函数。
    #                         3. 断言操作，判断预期与实际是否符合，将结果填入测试用例中。
    #                 '''
    #
#
# log = log_conf.get_log(r'..\Conf\log.ini')
# run(r'D:\selenium_testui\data\test_data.xlsx',log)