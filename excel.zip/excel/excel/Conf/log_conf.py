# -*- coding: utf-8 -*-
"""
@Time ： 2021/11/3 20:32
@Auth ： zhangye
@File ：log_conf.py
@IDE ：PyCharm
"""
'''
    生成日志器的配置
'''
import logging.config


# 路径一定要在调用的地方进行填写，不然会报错。  , encoding="utf-8"
def get_log(path):
    logging.config.fileConfig(path)
    return logging.getLogger()

if __name__ == '__main__':
    get_log(r'D:\pythonProject\excel\excel\Conf\log.ini')
