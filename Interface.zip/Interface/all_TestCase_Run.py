# -*- coding:utf-8 -*-
"""
@Time : 2022/8/3 13:21
@Author: zhangye
@File : all_TestCase_Run.py
"""
import pytest
import os
def run():
    pytest.main()
    #复制环境文件到报告文件里
    os.system('copy environment.properties Test_Case\\result\\environment.properties')
    #生成allure在线预览报告
    # os.system('allure serve ./Test_Case/result')
    #生成静态allure报告
    os.system('allure generate ./Test_Case/result/ -o ./Test_Case/report_allure/ --clean')

if __name__ == '__main__':
    run()