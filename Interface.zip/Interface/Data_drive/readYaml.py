# -*- coding:utf-8 -*-
"""
@Time : 2022/8/3 10:45
@Author: zhangye
@File : readYaml.py
"""
import yaml


class yaMl:
    #初始化文件
    def __init__(self,filename):
        self.filename=filename
     #yaml文件
    def read_Yaml(self):
        with open(self.filename, 'r', encoding='utf-8') as f:
           return yaml.load(f, yaml.FullLoader)
     #写入yaml文件
    def wirte_Yaml(self,data):
        with open(self.filename,'w',encoding='utf-8')as f:
            return yaml.dump(data,stream=f, allow_unicode=True)

     #更新yaml key的value
    def updata_Yaml(self,index,k,v,k2=None,k3=None,control=None):
        #单层字典
        if control ==None:
            old_data=self.read_Yaml()
            old_data[index][k]=v
            self.wirte_Yaml(old_data)
            #嵌套字典
        elif control==1:
            old_data = self.read_Yaml()
            old_data[index][k][k2]= v
            self.wirte_Yaml(old_data)
            #嵌套多层字典
        elif control==2:
            old_data = self.read_Yaml()
            old_data[index][k][k2][k3] = v
            self.wirte_Yaml(old_data)
        else:
            print('更新失败')





# if __name__ == '__main__':
#    pass