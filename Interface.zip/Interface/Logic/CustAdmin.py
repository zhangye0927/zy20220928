# -*- coding:utf-8 -*-
"""
@Time : 2022/8/17 16:48
@Author: zhangye
@File : CustAdmin.py
"""
import random
import datetime

import allure

from Data_drive.readYaml import yaMl
from KeyWord.Api_KeyWord import api_keyword

"""
全局变量大写
"""

URL=yaMl('./Conf/env.yaml').read_Yaml()['url']

class custAdmin:
    def custadd(self,custdata):
        #处理数据以及初始化工具类
        ak,custmod,custname,comptoken,systoken= custdata
        with allure.step("发送客户新增接口请求"):
            #新增客户url
            url=URL+'/pcapi/v2/customerWithContact/add'
            #新增数据
            data=yaMl('./Data/Customer parameters.yaml').read_Yaml()[0]
            res=ak.post(url=url,json=data)
            #声明全局变量custId
            global custId
            custId=ak.get_text(res.text,"custId")
            mailAddress=ak.get_text(res.text,"mailAddress")[0]
            contId = ak.get_text(res.text,'contId')
            up_custdata = yaMl('Data/bill_ID.yaml')
            up_custdata.updata_Yaml(0,'custId',custId)
            up_custdata.updata_Yaml(0,'contId',contId)
            up_custdata.updata_Yaml(0,'mailAddress',mailAddress)
            print("/pcapi/v2/customerWithContact/add接口请求参数:")
            print("请求url:", url)
            print("请求data:", data)
            print("/pcapi/v2/customerWithContact/add接口信息返回:")
            print("客户id(全局):", custId)
            print("response响应信息:", res.text)
            print("公司token:", comptoken)
            print("系统token:", systoken)
            assert ak.get_text(res.text,"msg") == "操作成功"



    def custsele(self,custdata):
        # 处理数据以及初始化工具类
        ak,custmod,custname,comptoken,systoken= custdata
        with allure.step("发送客户查询接口请求:"):
            url=URL+'/pcapi/v2/document/newStructSearch/do'
            data=yaMl('./Data/Customer parameters.yaml').read_Yaml()[1]
            data['accessToken']=comptoken
            data['individualAccessToken']=systoken
            data['keywords']=custname
            res=ak.post(url=url,json=data)
            print("/pcapi/v2/document/newStructSearch/do接口请求参数:")
            print("请求url:", url)
            print("请求data:", data)
            print("/pcapi/v2/document/newStructSearch/do接口信息返回:")
            print("response响应信息:", res.text)
            print("公司token:", comptoken)
            print("系统token:", systoken)
            assert ak.get_text(res.text,"msg") == '查询成功'



    def custmod(self,custdata):
        # 处理数据以及初始化工具类
        ak, custmod, custname, comptoken, systoken = custdata
        with allure.step("发送修改客户接口请求"):
            # 获取全局custId
            cusid = custId
            url = URL +'/pcapi/v2/document/generalOperate/put'
            data = yaMl('./Data/Customer parameters.yaml').read_Yaml()[2]
            data['accessToken'] = comptoken
            data['individualAccessToken'] = systoken
            data['identFieldValue'] = cusid
            data['custName']=custmod
            res = ak.put(url=url, json=data)
            print("/pcapi/v2/document/generalOperate/put接口请求参数:")
            print("请求url:", url)
            print("请求data:", data)
            print("/pcapi/v2/document/generalOperate/put接口信息返回:")
            print("客户id(全局):", custId)
            print("response响应信息:", res.text)
            print("公司token:", comptoken)
            print("系统token:", systoken)
            assert ak.get_text(res.text,"msg") == "操作成功"

    def custdel(self,custdata):

        ak, custmod, custname, comptoken, systoken = custdata
        with allure.step("发送删除客户到回收站接口请求"):
            # 获取全局custId
            cusid = custId
            url=URL+'/pcapi/v2/document/operate/detailOpt/put'
            data = yaMl('./Data/Customer parameters.yaml').read_Yaml()[3]
            data['accessToken'] = comptoken
            data['individualAccessToken'] = systoken
            data['identFieldValue'] = cusid
            res = ak.put(url=url, json=data)
            print("/pcapi/v2/document/operate/detailOpt/put接口请求参数:")
            print("请求url:", url)
            print("请求data:", data)
            print("/pcapi/v2/document/operate/detailOpt/put接口信息返回:")
            print("客户id(全局):", custId)
            print("response响应信息:", res.text)
            print("公司token:", comptoken)
            print("系统token:", systoken)
            assert ak.get_text(res.text, "msg") == "删除成功"

    def custrecover(self,custdata):
        ak, custmod, custname, comptoken, systoken = custdata
        with allure.step("发送彻底删除客户接口请求"):
            # 获取全局custId
            cusid = custId
            url = URL + '/pcapi/v2/document/operate/detailOpt/put'
            data = yaMl('./Data/Customer parameters.yaml').read_Yaml()[4]
            data['accessToken'] = comptoken
            data['individualAccessToken'] = systoken
            data['identFieldValue'] = cusid
            res = ak.put(url=url, json=data)
            print("/pcapi/v2/document/operate/detailOpt/put接口请求参数:")
            print("请求url:", url)
            print("请求data:", data)
            print("/pcapi/v2/document/operate/detailOpt/put接口信息返回:")
            print("客户id(全局):", custId)
            print("response响应信息:", res.text)
            print("公司token:", comptoken)
            print("系统token:", systoken)
            assert  ak.get_text(res.text, "msg") == "彻底删除成功"

