# -*- coding:utf-8 -*-
"""
@Time : 2022/8/25 19:19
@Author: zhangye
@File : business.py
"""
import allure

from Data_drive.readYaml import yaMl

"""
销售订单
"""

"""
全局变量大写
"""

URL=yaMl('./Conf/env.yaml').read_Yaml()['url']
class sale:

    def saleAdd(self,saledata):
        #初始化工具类
        ak,comptoken, systoken = saledata

        with allure.step("发送销售订单新增接口请求"):
            #新增客户url
            url=URL+'/pcapi/v2/document/quotation/post'
            #新增数据
            data=yaMl('./Data/Sales parameters.yaml').read_Yaml()[0]
            res=ak.post(url=url,json=data)
            #声明全局变量orderId
            global orderId
            orderId=ak.get_text(res.text,"orderId")
            up_saledata = yaMl('Data/bill_ID.yaml')
            up_saledata.updata_Yaml(1,'orderId',orderId)
            print("/pcapi/v2/document/quotation/post接口请求参数:")
            print("请求url:", url)
            print("请求data:", data)
            print("/pcapi/v2/document/quotation/post接口信息返回:")
            print("销售订单id(全局):",orderId )
            print("response响应信息:", res.text)
            print("公司token:", comptoken)
            print("系统token:", systoken)
            assert ak.get_text(res.text,"msg") == "操作成功"