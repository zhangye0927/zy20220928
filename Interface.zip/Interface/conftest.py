# -*- coding:utf-8 -*-
"""
@Time : 2022/8/16 13:59
@Author: zhangye
@File : conftest.py
"""
import datetime
import random

import allure

from Data_drive.readYaml import yaMl
from KeyWord.Api_KeyWord import api_keyword

import pytest
def pytest_collection_modifyitems(items):
    """
    测试用例收集完成时，将收集到的item的name和nodeid的中文显示在控制台上
    """
    for item in items:
        item.name = item.name.encode("utf-8").decode("unicode_escape")
        item._nodeid = item.nodeid.encode("utf-8").decode("unicode_escape")


"""
项目级fix，整个项目只初始化一次
"""

@pytest.fixture(scope='session')
@allure.step("发送post请求登录接口,生成token，整个项目只执行一次")
def token():
    # 登录接口
    url = yaMl('Conf/env.yaml').read_Yaml()['url'] + '/pcapi/v2/auth'
    # 登录数据
    data = yaMl('Data/Login.yaml').read_Yaml()
    #初始化api关键字类
    ak=api_keyword()

    res=ak.post(url=url,json=data)
    systoken,comptoken=ak.get_token(res.text,"储安琪线上发版0929测试企业")
    return ak,systoken,comptoken



"""
客户数据
"""
@pytest.fixture(scope='module')
@allure.step("客户管理模块级别数据fixture")
def custdata(token):
    #获取token
    ak, systoken, comptoken = token

    # data = yaMl('Data/Customer parameters.yaml').read_Yaml()

    # 获取系统当前时间日期
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # 处理联系人
    contName = 'test' + str(random.randint(1, 99999999))
    # 处理联系人邮箱
    contMail = ['testMl' + str(random.randint(1, 999999)) + '@qq.com']
    # 处理公司名称
    custName = 'testNa' + str(random.randint(1, 99999999))

    custName_mod='testNa' + str(random.randint(1, 99999999))
    print("初始化客户数据:")
    print("客户姓名:",custName)
    print("联系人姓名:",contName)
    print("修改后的客户姓名:",custName_mod)
    print("联系人邮箱:",contMail)
    print("当前时间:",now)
    print("公司token:",comptoken)
    print("系统token:",systoken)
    # 联系人  邮箱  公司名称 当前时间更新
    up_data=yaMl('Data/Customer parameters.yaml')
    up_data.updata_Yaml(0,'customer',custName,'custName',control=1)
    up_data.updata_Yaml(0,'customer',now,'actualCreateDate',control=1)
    up_data.updata_Yaml(0, 'custContact', contName, 'contName', control=1)
    up_data.updata_Yaml(0, 'custContact', contMail, 'mailAddress', control=1)
    up_data.updata_Yaml(0,'accessToken',comptoken)
    up_data.updata_Yaml(0,'individualAccessToken',systoken)

    return ak,custName_mod,custName,comptoken,systoken


"""
销售订单数据
"""
@pytest.fixture(scope='class')
@allure.step("销售订单类级别fixture")
def saledata(token):
    # 获取token
    ak, systoken, comptoken = token
    #处理订单主题
    orderTheme='testsale' + str(random.randint(1, 99999999))
    #客户id ，联系人id，邮箱
    cust_data=yaMl('Data/bill_ID.yaml').read_Yaml()[0]
    #更新订单客户id，联系人id，联系人邮箱，订单主题
    up_data = yaMl('Data/Sales parameters.yaml')
    up_data.updata_Yaml(0, 'orderTheme',orderTheme )
    up_data.updata_Yaml(0, 'custId',cust_data['custId'])
    up_data.updata_Yaml(0, 'mailAddress',cust_data['mailAddress'])
    up_data.updata_Yaml(0, 'contId', cust_data['contId'])
    up_data.updata_Yaml(0, 'accessToken', comptoken)
    up_data.updata_Yaml(0, 'individualAccessToken', systoken)
    print("初始化销售订单数据:")
    print("销售订单主题:",orderTheme)
    print("客户id:", cust_data['custId'])
    print("联系人id:", cust_data['contId'])
    print("联系人邮箱:", cust_data['mailAddress'])
    print("公司token:", comptoken)
    print("系统token:", systoken)

    return ak,comptoken,systoken






# if __name__ == '__main__':
#     a,b,c=token()
#     print(b)