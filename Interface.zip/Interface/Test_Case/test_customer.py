# -*- coding:utf-8 -*-
"""
@Time : 2022/8/18 15:17
@Author: zhangye
@File : test_customer.py
"""
import allure
from Logic.CustAdmin import custAdmin
import pytest
@allure.epic("孚盟外贸平台-接口测试")
class Test_cust(custAdmin):
    @pytest.mark.smoke
    @allure.feature("01.客户管理")
    @allure.story("01.客户管理核心场景")
    @allure.title("01.新增客户")
    def test_case01(self,custdata):
       self.custadd(custdata)

    @pytest.mark.smoke
    @pytest.mark.smoke
    @allure.feature("01.客户管理")
    @allure.story("01.客户管理核心场景")
    @allure.title("02.客户查询")
    def test_case02(self, custdata):
        self.custsele(custdata)

    @pytest.mark.smoke
    @allure.feature("01.客户管理")
    @allure.story("01.客户管理核心场景")
    @allure.title("03.客户修改")
    def test_case03(self, custdata):
        self.custmod(custdata)

    @pytest.mark.smoke
    @allure.feature("01.客户管理")
    @allure.story("01.客户管理核心场景")
    @allure.title("04.客户删除(放入回收站)")
    def test_case04(self, custdata):
        self.custdel(custdata)

    @pytest.mark.smoke
    @allure.feature("01.客户管理")
    @allure.story("01.客户管理核心场景")
    @allure.title("05.客户删除(彻底删除)")
    def test_case05(self, custdata):
        self.custrecover(custdata)