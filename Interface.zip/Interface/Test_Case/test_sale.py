# -*- coding:utf-8 -*-
"""
@Time : 2022/8/25 19:44
@Author: zhangye
@File : test_sale.py
"""
import allure
from Logic.CustAdmin import custAdmin
import pytest

from Logic.business import sale


@allure.epic("孚盟外贸平台-接口测试")
class Test_cust(sale,custAdmin):

    @pytest.mark.smoke
    @allure.feature("01.销售订单")
    @allure.story("01.销售订单核心场景")
    @allure.title("01.新增客户")
    def test_case01(self, custdata):
        self.custadd(custdata)


    @pytest.mark.smoke
    @allure.feature("01.销售订单")
    @allure.story("01.销售订单核心场景")
    @allure.title("02.销售订单新增")
    def test_case02(self,saledata):
       self.saleAdd(saledata)