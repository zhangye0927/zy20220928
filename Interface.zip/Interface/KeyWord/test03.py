# -*- coding:utf-8 -*-
"""
@Time : 2022/8/26 15:51
@Author: zhangye
@File : test03.py
"""
from KeyWord.Api_KeyWord import api_keyword

ak=api_keyword()

data={"user":"zhangye","pass":"513600zx","refer":"logon","event_source":"MX","operating_terminal":"pc_网页端","agent":"Chrome","agentVersion":"104.0.0.0","device":"pc","os":"Windows10","platform":"pc"}
url='https://fumamx.com/pcapi/v2/auth'
res=ak.post(url=url,json=data)
corpName=ak.get_text(res.text,"aId")
print(corpName)
print(res.text)

