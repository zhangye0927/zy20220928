# -*- coding:utf-8 -*-
"""
@Time : 2022/8/25 15:41
@Author: zhangye
@File : test01.py
"""
import json

from KeyWord.Api_KeyWord import api_keyword

data={"code":"0","data":{"autoTrigger":0,"ctId":1732062,"moduleCode":"BF001","optCode":"otNew","document":{"quotationCreateDate":"2022-08-25 15:37:14","custSort":"1","businessCreateDate":"2022-08-25 15:37:14","custContacts":[{"contCode":"TX08146","orderNo":"1","modifyDate":"2022-08-25 15:37:14","social":{"1":"","2":"","3":"","4":"","5":"","6":"","7":"","8":"","9":"","10":"","11":"","12":"","13":"","14":""},"mailAddress":["zy825001@qq.com"],"modifyCtId":"1732062","decisionMaker":"3","ownerDeptKey":"1","custName":"zy825001","suppType":"0","contId":1223013391,"sourceType":"3","primaryContact":1,"custId":"3613027578","delState":"0","contName":"zy825001","mailId":1191321313,"ownerCtId":"1732062","createCtId":"1732062","cId":"270531","createDate":"2022-08-25 15:37:14"}],"customerFlag":"1","actualCreateDate":"2022-08-25 15:36:19","customStr2":"YYDS无日期007","supplierFlag":"0","auditState":"3","orderCreateDate":"2022-08-25 15:37:14","custId":"3613027578","delState":"0","createCtId":"1732062","cId":"270531","createDate":"2022-08-25 15:37:14","modifyDate":"2022-08-25 15:37:14","seasFlag":"0","modifyCtId":"1732062","custName":"zy825001","custLevel":"100","ownerDeptKey":"1","custCode":"CU22082500005","suppType":"0","sourceType":"3","seasGroup":"1","custState":"1","customDate100":"2022-08-25 15:36:19","ownerCtId":"1732062"},"accessToken":"RtrqEACT3vk1mZXC"},"lMsg":{"data":{},"key":"api.1528870186768"},"msg":"操作成功","ApiTime":0.753,"version":"60e57e990b89fdaea00c1edf35a1cb0f"}
data1=json.dumps(data)
print(type(data1))
ak=api_keyword()
contId=ak.get_text(data1,'contId')
mailAddress=ak.get_text(data1,"mailAddress")
print(contId)
print(mailAddress[0])