# -*- coding:utf-8 -*-
"""
@Time : 2022/8/15 15:18
@Author: zhangye
@File : Api_KeyWord.py
"""
"""
    jsonpath表达式的基本格式规范：
        $ 表示根节点，也是所有jsonpath表达式的开始
        . 表示获取子节点
        .. 表示获取所有符合条件的内容
        *  代表所有的元素节点
        [] 表示迭代器的标示（可以用于处理下标等情况）
        [,] 表示多个结果的选择
        ?() 表示过滤操作
        @ 表示当前节点
"""
import json

import requests
import jsonpath
class api_keyword:
    # get请求的封装：因为params可能存在无值的情况，存放默认None
    def get(self,url,params=None,**kwargs):
        return  requests.get(url=url,params=params,**kwargs)

    # post请求的封装：data也可能存在无值得情况，存放默认None
    def post(self,url,data=None,**kwargs):
        return  requests.post(url=url,data=data,**kwargs)

    # put请求的封装：data也可能存在无值得情况，存放默认None
    def put(self,url, data=None, **kwargs):
        return  requests.put(url=url,data=data,**kwargs)

    #获取文本信息
    def get_text(self,data,key):
        # jsonpath获取数据的表达式：成功则返回list，失败则返回false
        # loads是将json格式的内容转换为字典的格式
        # jsonpath接收的是dict类型的数据
        dict_data = json.loads(data)
        value = jsonpath.jsonpath(dict_data,'$..{0}'.format(key))
        return value[0]

     #获取token
    def get_token(self,data,value):
        dict_data = json.loads(data)
        systoken=jsonpath.jsonpath(dict_data,'$.data.accessToken.value')
        comptoken=jsonpath.jsonpath(dict_data,'$..companies[?(@.corpName=="{}")].accessToken.value'.format(value))
        return  systoken[0],comptoken[0]